<footer class="vestidos-footer vest-maincolor">
    @include('includes.footer')
</footer>