@extends('admin/layouts.app')
@section('content')
<h1>New Product</h1>
@endsection