@extends('admin/layouts.app')
@section('content')
    <h1>First Content</h1>
@endsection