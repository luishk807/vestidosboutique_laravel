@include('includes.header')   
@yield('content')
</body>
</html>