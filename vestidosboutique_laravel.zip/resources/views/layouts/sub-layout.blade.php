@include('includes.header')   
@yield('content')
@include('includes.footer-main')
</body>
</html>