<?php $__env->startSection('content'); ?>
<div class="main_sub_body about_bg main_body_height">
<div class="container-fluid">
    <div class="row">
        <div class="col-lg-9 container-in-center">
            <div>
               <div class="container-in-space white-md-bg-in about-col">
                    <h2>Our Story</h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur bibendum ac lacus sed finibus. Integer auctor urna a magna tristique porttitor. Aliquam nec tortor tellus. Nunc dignissim enim feugiat euismod ullamcorper. Sed sed purus porta, dictum lorem vitae, elementum nulla. Nunc consequat at nibh quis molestie. Nullam ut dictum orci. Mauris mollis odio eu justo tincidunt tristique. Sed vehicula massa quis magna semper volutpat. Sed gravida purus a neque tincidunt molestie. Suspendisse eget condimentum nibh, in tincidunt dui. Donec lorem tellus, rutrum posuere risus in, malesuada rutrum dolor. Fusce quis facilisis dui. Aliquam vitae leo a elit mattis cursus.</p>
                    <h2>Our Mission</h2>
        <p>Suspendisse eros lorem, fermentum auctor leo quis, convallis aliquet tellus. Proin dictum ullamcorper interdum. Aliquam quis justo pharetra, malesuada ligula at, tempor risus. Proin ullamcorper ipsum nec ex facilisis, quis aliquam ex sollicitudin. Donec pretium tincidunt imperdiet. Morbi consectetur sit amet ex quis scelerisque. Sed nec sollicitudin justo, quis dapibus turpis. Duis volutpat dui tempor nisl luctus iaculis. In ut dui interdum, pulvinar ex a, tempor urna. Maecenas ullamcorper diam dolor, mattis posuere ante tempus vitae. Pellentesque nec elit quis augue pulvinar fermentum.</p>
                    <div><img src="<?php echo e(asset('images/vesti-signature.png')); ?>" alt/></div>
               </div>
            </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.sub-layout", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>