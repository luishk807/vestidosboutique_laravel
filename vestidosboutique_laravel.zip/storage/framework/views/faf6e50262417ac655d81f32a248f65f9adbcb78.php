<?php $__env->startSection('content'); ?>
<div class="main_sub_body main_body_height">
<div class="container-fluid">
    <div class="row">
        <div class="col container-in-center">
            <div>
               <div class="container-in-space white-md-bg-in">
                        



                    <h2>Thank you</h2>

               </div><!--end of container-in-space-->
            </div>
        </div><!--end of container-in-center container-->
    </div><!--end of row-->
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.sub-layout", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>