<?php $__env->startSection('content'); ?>
<div class="main_sub_body main_body_height">
<div class="container-fluid">
    <div class="row">
        <div class="col-lg-9 container-in-center">
            <div>
               <div class="container-in-space white-md-bg-in">
                    <div class="container account-container">
                        <div class="row">
                            <div class="col-md-8 account-form-section">
                                <h2><?php echo e($page_title); ?></h2>
                                <form action="<?php echo e(route('createclient')); ?>" method="post">
                                <div class="form-group">
                                        <label class="accountTitleSelect" for="accountTitle">Select Title:</label>
                                        <select class="custom-select accountTitleSelect" name="title" id="accountTitle">
                                            <option selected>Select Title</option>
                                            <?php for($i=0;$i<sizeof($titles);$i++): ?>
                                                <option value="<?php echo e($titles[$i]); ?>"><?php echo e($titles[$i]); ?></option>
                                            <?php endfor; ?>
                                        </select>
                                </div>
                                <div class="form-row">
                                    <div class="form-group col-md-6">
                                        <label for="accountFirstName">First Name:</label>
                                        <input type="text" id="accountFirstName" class="form-control" name="first_name" value="" placeholder="First Name"/>
                                        <small class="error"><?php echo e($errors->first("first_name")); ?></small>
                                    </div>
                                    <div class="form-group col-md-6">
                                        <label for="accountLastName">Last Name:</label>
                                        <input type="text" id="accountLastName" class="form-control" name="last_name" value="" placeholder="Last Name"/>
                                        <small class="error"><?php echo e($errors->first("last_name")); ?></small>
                                    </div>
                                </div>
                                <div class="form-group">
                                        <label for="accountEmail">Email:</label>
                                        <input type="email" id="accountEmail" class="form-control" name="email" value="" placeholder="Email"/>
                                        <small class="error"><?php echo e($errors->first("email")); ?></small>
                                </div>
                                <div class="form-group">
                                        <label for="accountPhone">Phone:</label>
                                        <input type="tel" id="accountPhone" class="form-control" name="phone" value="" placeholder="Phone Number"/>
                                        <small class="error"><?php echo e($errors->first("phone")); ?></small>
                                </div>
                                <div class="form-group">
                                        <label for="accountPassword">Password:</label>
                                        <input type="password" id="accountPassword" class="form-control" name="password" value="" placeholder="Password"/>
                                        <small class="error"><?php echo e($errors->first("password")); ?></small>
                                </div>
                                <div class="form-group">
                                        <label for="accountRePassword">Re-Type Password:</label>
                                        <input type="password" id="accountRePassword" class="form-control" name="repassword" value="" placeholder="Re-Type Password"/>
                                </div>
                                <div class="form-group">
                                        <label class="accountCountrySelect" for="accountCountry">Select Country:</label>
                                        <select class="custom-select accountCountrySelect" name="country" id="accountCountry">
                                            <option selected>Select Country</option>
                                        </select>
                                        <small class="error"><?php echo e($errors->first("country")); ?></small>
                                </div>
                                <div class="form-row">
                                    <div class="form-group col-md-6">
                                            <label for="accountCity">City:</label>
                                            <input type="text" id="accountCity" class="form-control" name="city" value="" placeholder="City"/>
                                            <small class="error"><?php echo e($errors->first("city")); ?></small>
                                    </div>
                                    <div class="form-group col-md-6">
                                            <label for="accountPostal">Zip Code:</label>
                                            <input type="text" id="accountPostal" class="form-control" name="postal_code" value="" placeholder="Postal Code"/>
                                            <small class="error"><?php echo e($errors->first("postal_code")); ?></small>
                                    </div>
                                </div>
                                <div class="vesti_in_btn_pnl">
                                    <input type="submit" class="btn-block vesti_in_btn" value="Sign Up"/>
                                </div>
                                </form>
                            </div><!--end of form container-->
                        </div>
                    </div>
               </div>
            </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.sub-layout", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>